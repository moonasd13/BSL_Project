using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestHandler : StopItemSlot
{
    void Start()
    {

    }
    void Update()
    {
        
    }
}
