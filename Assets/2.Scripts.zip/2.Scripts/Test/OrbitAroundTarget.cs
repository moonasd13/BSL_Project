using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//public class OrbitAroundTarget : MonoBehaviour
//{
//    public Transform target;      // ������ �Ǵ� ���ӿ�����Ʈ
//    public float rotateSpeed = 50f; // ȸ�� �ӵ� (��/��)
//    public Vector3 rotateAxis = Vector3.up; // ȸ�� ��

//    private void Start()
//    {
//        //target = transform.parent;
//        //transform.SetParent(null);
//        target = GameObject.Find("SkillManager").GetComponent<Transform>();
//    }
//    void Update()
//    {
//        if (target == null) return;

//        transform.RotateAround(
//            target.position,
//            rotateAxis,
//            rotateSpeed * Time.deltaTime
//        );
//    }

//    private void OnTriggerEnter(Collider other)
//    {
//        if (other.CompareTag("Monster"))
//        {
//            Debug.Log("Hit");
//            Destroy(other.gameObject);
//        }
//    }
//}

using UnityEngine;

public class OrbitAroundTarget : MonoBehaviour
{
    public Transform target;
    public float rotateSpeed = 180f;
    public Vector3 orbitAxis = Vector3.up;
    public Transform Test;
    public int index;

    private Vector3 offset;

    void Start()
    {
        Test = transform.parent;

        Test.transform.SetParent(null);

        // �θ� �и�
        //transform.SetParent(null);

        target = GameObject.Find("SkillManager").GetComponent<Transform>();

        Test.parent = target;

        // �ʱ� ������ ����
        offset = transform.position - target.position;
        transform.Rotate(0, 90, -90);

        int invensize = InventoryManager._uniqInstance.InvenInitems.Count;
        if (invensize == 0)
            invensize = 1;
        float rotateAngle = index * (360 / invensize);

        offset = Quaternion.AngleAxis(
            rotateAngle,
            orbitAxis
        ) * offset;


        //Debug.Log(offset);



        // �׻� target ��ġ ����
        transform.position = target.position + offset;
        //transform.rotation =  //Quaternion.Euler(0 , rotateSpeed * Time.deltaTime, 0);

        transform.Rotate(-rotateAngle, 0, 0);

    }

    void LateUpdate()
    {
        if (target == null) return;

        // ������ ��ü�� ȸ��
        offset = Quaternion.AngleAxis(
            rotateSpeed * Time.deltaTime,
            orbitAxis
        ) * offset;


        //Debug.Log(offset);



        // �׻� target ��ġ ����
        transform.position = target.position + offset;
        //transform.rotation =  //Quaternion.Euler(0 , rotateSpeed * Time.deltaTime, 0);
        transform.Rotate(-rotateSpeed * Time.deltaTime , 0, 0);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Monster"))
        {
            Destroy(other.gameObject);
        }
    }
}

