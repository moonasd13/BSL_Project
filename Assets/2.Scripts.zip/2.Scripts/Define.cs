using System.Collections;
using System.Collections.Generic;

namespace Define
{
    public enum ItemType
    {
        Weapon,
        Stats,
        AdditionalEffects
    }
    public enum MonsterType
    {
        Normal,
        Boss
    }
    public enum ItemName
    {
        Axe,
        HockeyStick,
        SniperRifle
    }
    public enum ItemState
    {
        Store,
        Inven
    }
}
